import React from 'react'
import { StyleSheet, Text, View} from 'react-native';

import { NavigationContainer} from '@react-navigation/native';
import { createNativeStackNavigator} from '@react-navigation/native-stack';

import Inicial from './src/telas/Inicial';
import Informações from './src/telas/Informações';
import Pokedex from './src/telas/Pokedex';
import Usuário from './src/telas/Usuário';

import{Ionicons} from '@expo/vector-icons';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import { url } from 'inspector';

  const Tab = createBottomTabNavigator();
  
  function Tabs(){
     
    return(
      <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size}) => {
        let iconName;
        color= '#00138f'
        size = 30
        if (route.name === 'Informações') {
          iconName = focused
            ? 'home-outline'
            : '"person-circle-outline"';
        } else if (route.name === 'Usuário') {
          iconName = focused ? 'person-outline' : 'body-outline';
        }else if (route.name === 'Pokedex') {
          iconName = focused ? 'people-outline' : 'happy-outline';
        }else if (route.name === 'Inicial') {
          iconName = focused ? 'people-outline' : 'happy-outline';
        }
        
        //aqui define os ícones que irão aparecer nas Tabs
        return <Ionicons name={iconName} size={size} color={color} />;
      },
    })}
    tabBarOptions={{
      labelStyle: {
        fontSize: 12},
      activeTintColor: '#3f64c7',
      inactiveTintColor: 'gray',      
    }}    
    >
      <Tab.Screen name= "Informações" component={Informações}></Tab.Screen>
      <Tab.Screen name= "Pokedex" component={Pokedex}></Tab.Screen>
      <Tab.Screen name= "Usuário" component={Usuário}></Tab.Screen>
    </Tab.Navigator>
    )
  }

export default function App() {
  const Stack = createNativeStackNavigator();
  const Tab = createBottomTabNavigator();
  return (

  <NavigationContainer>
    <Stack.Navigator initialRouteName='Inicial'> 
  
      <Stack.Screen 
          name="Informações"  
          component={Tabs}
          options={{ // Opções do Header
            title:'Meu Aplicativo', // Título
            headerStyle:{ // Folha de estilo do header
            backgroundColor: '#b03123', // Propriedades da folha de estilo. (cor de fundo)
            },
            headerTintColor: '#f2eceb' ,  // Cor dos textos do header
            headerShown: true     // Seleção principal de estado do header (mostrando como principal)
          }}
          >
  
      </Stack.Screen>
      <Stack.Screen name="Usuário" component={Usuário}></Stack.Screen>
      <Stack.Screen name="Pokedex" component={Pokedex}></Stack.Screen>
      <Stack.Screen name="Inicial" component={Inicial} options={{headerShown: false}} /* option para esconder o header */></Stack.Screen> 
    </Stack.Navigator>
  </NavigationContainer>
  );
}
const styles = StyleSheet.create({
 
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});