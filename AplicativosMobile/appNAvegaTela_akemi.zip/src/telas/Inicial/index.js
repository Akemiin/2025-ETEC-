import React from 'react';
import { StyleSheet, Text, View, Image, Button,ImageBackground } from 'react-native';
import Pokedex from '../Pokedex';

export default function Inicial({navigation}){
    return(
        <View style={styles.container}>
          <ImageBackground source={require("../../../assets/wallpaper-inicial.jpg")} resizeMode='cover' style={styles.image}>
            <Text>inicial</Text>
            <Button
            title="Entrar no aplicativo"
            onPress={() => navigation.navigate('Informações')}
            >
            </Button>
          </ImageBackground>
        </View>
    )
};

const styles = StyleSheet.create({
  container: {

    flex: 1,
    backgroundColor: '#63605f',
    justifyContent: 'center',
  },
  image:{
    justifyContent: 'center',
    width:736,
    lineHeighteight:1708,
  }
});