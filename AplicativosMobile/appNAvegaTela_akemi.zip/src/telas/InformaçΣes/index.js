import React from 'react';
import { StyleSheet, Text, View, Image, Button } from 'react-native';

export default function Informações({navigation}){
    return(
        <View style={styles.container}>
            <Text>Informações de usuário</Text>
        </View>
    )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#63605f',
    alignItems: 'center',
    justifyContent: 'center',
  },
});