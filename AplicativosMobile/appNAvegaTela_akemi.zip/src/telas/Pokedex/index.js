import React from 'react';
import { StyleSheet, Text, View, Image, Button } from 'react-native';

export default function Pokedex({navigation}){
    return(
        <View style={styles.container}>
            <Text>Pokedex atual</Text>
        </View>
    )
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#63605f',
    alignItems: 'center',
    justifyContent: 'center',
  },
});